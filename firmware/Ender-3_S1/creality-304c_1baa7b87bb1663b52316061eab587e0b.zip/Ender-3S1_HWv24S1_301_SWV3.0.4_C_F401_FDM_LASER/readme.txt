*Upgrade completed to restore factory settings

May 6, 2022 (Firmware: V3.0.4_C/V1.0.7_C)
1. fix the alignment problem in Control->Motion->Max Speed/Max Acceleration/Max Corner Speed/Drive Ratio interface
2. fix the alignment problem in the interface of Prepare->Axis Move

20220427
1. fix the problem of offset lost step issue at the same time.
2. fix the problem of option checking and unchecking fonts in the interface of engraving warning
3. fix the delay problem of 24C16F. 4.
4. fix the problem that Steps-per-mm X Y Z distance is far and not aligned in the interface of transmission ratio.
5. Fix the problem of high and low temperature pop-up window. 6.
6. print/engraving finished Change the title of Chinese and English interface to Finish/engraving finished (Finish/Finish)
7. fix the problem that the laser/FDM interface is not aligned.

20220104 1.
1. fix the bug that the printing warning interface and the setting interface cannot run the border after the axis is moved in the laser mode.

20211231 1.
1. fix the bug that FDM cloud printing returns to zero several times.

20211230 1.
1. fix the bug that the Z-axis drops when switching to laser mode after FDM returns to zero.

20211229 1.
1. modify the interface of zero return, leveling, extruder, material break detection, and power failure to change the Chinese of the pop-up interface to mapping to fix the problem that the font background color does not match.
2. repair the interface prompt of "laser engraving" to "Pause engraving" ("Pause engraving")
3. fix the "Stop engraving" prompt in the "Laser engraving" interface to "Stop engraving" ("Stop engraving")
4. modify the "Switch laser engraving" warning screen and the focus screen in the "Control" screen in laser mode to not show the title.

20211227
Merge Ender-3S1. 1:
1. Optimize the problem that when printing is stopped, the nozzle will fast charge for a while before stopping printing.
2. Optimize the risk of hitting the platform when manually adjusting the Z-axis height by unlocking the motor. 3.
3. Optimize the minimum protection temperature of the printer, from 5�� to 0��. 4.
4. Auto leveling operation will not turn off the temperature of nozzle and hot bed before.
